import type { EbayListing, EbayListingDetails } from '@/lib/ebay';
import type { ScpCandidate } from '@/lib/scp';
import { compactWhitespace, tokenizeLoose } from '@/lib/utils';

export type CardFingerprint = {
  normalizedText: string;
  year: string | null;
  playerName: string | null;
  brand: string | null;
  setName: string | null;
  familyKey: string | null;
  cardNumber: string | null;
  parallel: string | null;
  serialNumbered: boolean | null;
  serialNumberText: string | null;
  serialNumberDenominator: string | null;
  rookie: boolean | null;
  autograph: boolean | null;
  memorabilia: boolean | null;
  graded: boolean | null;
  raw: boolean | null;
  team: string | null;
  tokens: string[];
  keyHints: string[];
};

type FingerprintAspectMap = Record<string, string[]>;

const PARALLEL_TERMS = [
  'black finite',
  'gold vinyl',
  'gold shimmer',
  'blue shimmer',
  'red shimmer',
  'orange pulsar',
  'red wave',
  'blue wave',
  'hyper prizm',
  'silver prizm',
  'green prizm',
  'mojo prizm',
  'choice red',
  'choice blue',
  'white sparkle',
  'cracked ice',
  'scope',
  'mojo',
  'pulsar',
  'refractor',
  'xfractor',
  'atomic',
  'speckle',
  'pink',
  'purple',
  'orange',
  'red',
  'blue',
  'green',
  'gold',
  'silver',
  'bronze',
  'teal',
  'aqua',
  'sepia',
  'rainbow',
  'velocity',
  'ice',
  'wave',
  'galaxy',
  'checkerboard',
  'laser',
  'phoenix',
  'neon green',
  'holo',
];

const BRAND_TERMS = [
  'panini prizm',
  'panini select',
  'panini optic',
  'panini donruss',
  'panini mosaic',
  'topps chrome',
  'topps finest',
  'topps bowman chrome',
  'bowman chrome',
  'bowman best',
  'bowman sterling',
  'upper deck',
  'fleer ultra',
  'leaf metal',
  'donruss optic',
  'select',
  'prizm',
  'optic',
  'mosaic',
  'donruss',
  'bowman',
  'topps',
  'leaf',
  'upper deck',
];

const SET_HINTS = [
  'rookie ticket',
  'downtown',
  'kaboom',
  'color blast',
  'my house',
  'stained glass',
  'pandora',
  'bomb squad',
  'marvels',
  'seismic',
  'genesis',
  'dragon scale',
  'v color',
  'blue scope',
  'white sparkle',
  'checkerboard',
  'prizm',
  'select',
  'optic',
  'mosaic',
];

const FAMILY_TERMS = [
  'panini prizm',
  'prizm',
  'panini select',
  'select',
  'panini optic',
  'optic',
  'panini mosaic',
  'mosaic',
  'topps chrome',
  'bowman chrome',
  'donruss optic',
  'donruss',
  'rookie ticket',
  'downtown',
  'kaboom',
  'color blast',
  'my house',
  'stained glass',
  'genesis',
  'checkerboard',
];

export function buildListingFingerprint(
  listing: Pick<EbayListing, 'title' | 'condition'>,
  options?: { details?: Pick<EbayListingDetails, 'subtitle' | 'description' | 'aspectMap'> | null; ximilarHints?: string[] | null },
): CardFingerprint {
  const mergedText = compactWhitespace([
    listing.title,
    options?.details?.subtitle ?? '',
    options?.details?.description ?? '',
    ...(options?.ximilarHints ?? []),
  ].filter(Boolean).join(' '));

  return buildFingerprintFromText(mergedText, {
    aspectMap: options?.details?.aspectMap ?? {},
    condition: listing.condition ?? null,
  });
}

export function buildScpCandidateFingerprint(candidate: Pick<ScpCandidate, 'productName' | 'consoleName'>): CardFingerprint {
  const mergedText = compactWhitespace([candidate.productName, candidate.consoleName ?? ''].filter(Boolean).join(' '));
  return buildFingerprintFromText(mergedText, { aspectMap: {}, condition: null });
}

export type FingerprintComparison = {
  score: number;
  positiveSignals: string[];
  negativeSignals: string[];
};

export function scoreFingerprintSimilarity(listingFingerprint: CardFingerprint, candidateFingerprint: CardFingerprint): number {
  return compareFingerprintMatch(listingFingerprint, candidateFingerprint).score;
}

export function normalizeFamilyKey(value: string | null | undefined): string | null {
  if (!value) return null;
  const normalized = compactWhitespace(String(value)).toLowerCase();
  for (const family of [...FAMILY_TERMS].sort((a, b) => b.length - a.length)) {
    if (normalized.includes(family)) return family.replace(/^panini\s+/, '');
  }
  return null;
}

export function compareFingerprintMatch(listingFingerprint: CardFingerprint, candidateFingerprint: CardFingerprint): FingerprintComparison {
  let score = 0;
  const positiveSignals: string[] = [];
  const negativeSignals: string[] = [];

  if (listingFingerprint.year && candidateFingerprint.year) {
    if (listingFingerprint.year === candidateFingerprint.year) {
      score += 14;
      positiveSignals.push(`Year ${listingFingerprint.year}`);
    } else {
      score -= 12;
      negativeSignals.push(`Year mismatch (${listingFingerprint.year} vs ${candidateFingerprint.year})`);
    }
  }
  if (listingFingerprint.familyKey && candidateFingerprint.familyKey) {
    if (listingFingerprint.familyKey === candidateFingerprint.familyKey) {
      score += 18;
      positiveSignals.push(`Set family ${candidateFingerprint.familyKey}`);
    } else {
      score -= 18;
      negativeSignals.push(`Set family mismatch (${listingFingerprint.familyKey} vs ${candidateFingerprint.familyKey})`);
    }
  }
  if (listingFingerprint.cardNumber && candidateFingerprint.cardNumber) {
    if (listingFingerprint.cardNumber === candidateFingerprint.cardNumber) {
      score += 18;
      positiveSignals.push(`Card #${listingFingerprint.cardNumber}`);
    } else {
      score -= 14;
      negativeSignals.push(`Card # mismatch (${listingFingerprint.cardNumber} vs ${candidateFingerprint.cardNumber})`);
    }
  }
  if (listingFingerprint.parallel && candidateFingerprint.parallel) {
    if (listingFingerprint.parallel === candidateFingerprint.parallel) {
      score += 12;
      positiveSignals.push(`Parallel ${candidateFingerprint.parallel}`);
    } else {
      score -= 10;
      negativeSignals.push(`Parallel mismatch (${listingFingerprint.parallel} vs ${candidateFingerprint.parallel})`);
    }
  }
  if (listingFingerprint.serialNumbered !== null && candidateFingerprint.serialNumbered !== null) {
    if (listingFingerprint.serialNumbered === candidateFingerprint.serialNumbered) {
      score += 6;
      positiveSignals.push(listingFingerprint.serialNumbered ? 'Both serial-numbered' : 'Both unnumbered');
    } else {
      score -= 6;
      negativeSignals.push('Serial-numbering mismatch');
    }
  }
  if (listingFingerprint.serialNumberDenominator && candidateFingerprint.serialNumberDenominator) {
    if (listingFingerprint.serialNumberDenominator === candidateFingerprint.serialNumberDenominator) {
      score += 6;
      positiveSignals.push(`Print run /${listingFingerprint.serialNumberDenominator}`);
    } else {
      score -= 5;
      negativeSignals.push(`Print-run mismatch (/${listingFingerprint.serialNumberDenominator} vs /${candidateFingerprint.serialNumberDenominator})`);
    }
  }
  if (listingFingerprint.autograph !== null && candidateFingerprint.autograph !== null) {
    if (listingFingerprint.autograph === candidateFingerprint.autograph) {
      score += 5;
      if (listingFingerprint.autograph) positiveSignals.push('Autograph aligned');
    } else {
      score -= 5;
      negativeSignals.push('Autograph mismatch');
    }
  }
  if (listingFingerprint.memorabilia !== null && candidateFingerprint.memorabilia !== null) {
    if (listingFingerprint.memorabilia === candidateFingerprint.memorabilia) {
      score += 5;
      if (listingFingerprint.memorabilia) positiveSignals.push('Memorabilia aligned');
    } else {
      score -= 5;
      negativeSignals.push('Memorabilia mismatch');
    }
  }
  if (listingFingerprint.rookie !== null && candidateFingerprint.rookie !== null) {
    if (listingFingerprint.rookie === candidateFingerprint.rookie) {
      score += 4;
      if (listingFingerprint.rookie) positiveSignals.push('Rookie aligned');
    } else {
      score -= 4;
      negativeSignals.push('Rookie mismatch');
    }
  }
  if (listingFingerprint.brand && candidateFingerprint.brand) {
    if (listingFingerprint.brand === candidateFingerprint.brand) {
      score += 8;
      positiveSignals.push(`Brand ${candidateFingerprint.brand}`);
    } else if (!normalizeFamilyKey(listingFingerprint.brand) || !normalizeFamilyKey(candidateFingerprint.brand) || normalizeFamilyKey(listingFingerprint.brand) !== normalizeFamilyKey(candidateFingerprint.brand)) {
      score -= 6;
      negativeSignals.push(`Brand mismatch (${listingFingerprint.brand} vs ${candidateFingerprint.brand})`);
    }
  }
  if (listingFingerprint.raw === true && candidateFingerprint.graded === true) {
    score -= 6;
    negativeSignals.push('Grading mismatch (listing raw, SCP graded)');
  }
  if (listingFingerprint.graded === true && candidateFingerprint.raw === true) {
    score -= 6;
    negativeSignals.push('Grading mismatch (listing graded, SCP raw)');
  }

  const overlap = listingFingerprint.tokens.filter((token) => candidateFingerprint.tokens.includes(token));
  score += Math.min(10, overlap.length);
  if (overlap.length > 0) {
    positiveSignals.push(`${Math.min(10, overlap.length)} shared text token${overlap.length === 1 ? '' : 's'}`);
  }

  return {
    score,
    positiveSignals: positiveSignals.slice(0, 5),
    negativeSignals: negativeSignals.slice(0, 5),
  };
}

function buildFingerprintFromText(
  text: string,
  options: { aspectMap: FingerprintAspectMap; condition: string | null },
): CardFingerprint {
  const normalizedText = compactWhitespace(text).toLowerCase();
  const tokens = tokenizeLoose(normalizedText).slice(0, 48);
  const year = extractYear(normalizedText);
  const aspectMap = options.aspectMap ?? {};

  const playerName = firstAspectValue(aspectMap, ['player athlete', 'athlete', 'player']) ?? null;
  const team = firstAspectValue(aspectMap, ['team', 'professional sports authen']) ?? null;
  const brand = extractBestTerm(normalizedText, BRAND_TERMS) ?? firstAspectValue(aspectMap, ['manufacturer', 'brand']);
  const setName = firstAspectValue(aspectMap, ['set', 'insert set']) ?? extractBestTerm(normalizedText, SET_HINTS);
  const familyKey = normalizeFamilyKey([brand, setName, normalizedText].filter(Boolean).join(' '));
  const cardNumber = firstAspectValue(aspectMap, ['card number']) ?? extractCardNumber(normalizedText);
  const parallel = firstAspectValue(aspectMap, ['parallel variety', 'parallel']) ?? extractBestTerm(normalizedText, PARALLEL_TERMS);
  const serialNumberText = firstAspectValue(aspectMap, ['print run', 'serial number', 'serial numbered']) ?? extractSerialNumberText(normalizedText);
  const serialNumberDenominator = extractSerialNumberDenominator(serialNumberText);
  const serialNumbered = serialNumberText ? true : inferBoolean(normalizedText, ['numbered', '/'], ['unnumbered']);
  const rookie = inferBoolean(normalizedText, ['rookie', 'rc'], ['non rookie']);
  const autograph = inferBoolean(normalizedText, ['auto', 'autograph'], ['non auto', 'no auto']);
  const memorabilia = inferBoolean(normalizedText, ['patch', 'relic', 'memorabilia', 'jersey'], ['non patch', 'no relic']);
  const graded = inferBoolean(`${normalizedText} ${options.condition ?? ''}`.toLowerCase(), ['psa', 'bgs', 'sgc', 'cgc', 'graded'], ['raw']);
  const raw = inferBoolean(`${normalizedText} ${options.condition ?? ''}`.toLowerCase(), ['raw', 'ungraded'], ['graded', 'psa', 'bgs', 'sgc', 'cgc']);

  const keyHints = [year, playerName, brand, setName, familyKey, cardNumber, parallel, serialNumberText]
    .filter((value): value is string => Boolean(value))
    .slice(0, 8);

  return {
    normalizedText,
    year,
    playerName,
    brand,
    setName,
    familyKey,
    cardNumber,
    parallel,
    serialNumbered,
    serialNumberText,
    serialNumberDenominator,
    rookie,
    autograph,
    memorabilia,
    graded,
    raw,
    team,
    tokens,
    keyHints,
  };
}

function extractYear(text: string): string | null {
  const match = text.match(/(19\d{2}|20\d{2})/);
  return match?.[1] ?? null;
}

function extractCardNumber(text: string): string | null {
  const hashMatch = text.match(/(?:^|\s)#\s*([a-z0-9-]{1,10})(?=\s|$)/i);
  if (hashMatch?.[1]) return hashMatch[1].toUpperCase();
  const numberMatch = text.match(/(?:card|no|number)\s*#?\s*([a-z0-9-]{1,10})/i);
  return numberMatch?.[1]?.toUpperCase() ?? null;
}

function extractSerialNumberText(text: string): string | null {
  const match = text.match(/\d+\s*\/\s*\d+/);
  return match ? match[0].replace(/\s+/g, '') : null;
}

function extractSerialNumberDenominator(value: string | null): string | null {
  if (!value) return null;
  const match = value.match(/\/(\d+)/);
  return match?.[1] ?? null;
}

function extractBestTerm(text: string, terms: string[]): string | null {
  for (const term of [...terms].sort((a, b) => b.length - a.length)) {
    if (text.includes(term)) return term;
  }
  return null;
}

function inferBoolean(text: string, positiveTerms: string[], negativeTerms: string[]): boolean | null {
  if (negativeTerms.some((term) => text.includes(term))) return false;
  if (positiveTerms.some((term) => text.includes(term))) return true;
  return null;
}

function firstAspectValue(aspectMap: FingerprintAspectMap, keys: string[]): string | null {
  for (const key of keys) {
    const value = aspectMap[key]?.[0];
    if (value) return compactWhitespace(value);
  }
  return null;
}
